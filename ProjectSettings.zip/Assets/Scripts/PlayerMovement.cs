using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float Speed = 1.0f;
    public float _JumpForce = 1.0f;
    public float RotationSpeed = 1.0f;
    public Transform GroundCheck;
    public Transform CubeVisual;
    public float TimeBetweenParticles = 0.1f;
    public ParticleSystem DeadParticles;
    private int _Obstacle;
    public Rigidbody2D Rigidbody2D;
    private bool _Jump;
    private bool _JumpTop;
    public bool Dead;
    private bool _WasGround;
    private bool _touchUp;

    private void Awake()
    {
        _Obstacle = LayerMask.NameToLayer("_Obstacle");
    }

    private void Update()
    {
        if (Dead) return;

        bool ground = Physics2D.Raycast(GroundCheck.transform.position, Vector2.down, 0.05f);

        if (ground || _touchUp)
        {
            Quaternion rot = CubeVisual.rotation;
            rot.z = 0.0f;
            CubeVisual.rotation = rot;
        }
        else
        {
            CubeVisual.Rotate(Vector3.back * RotationSpeed * Time.deltaTime);
        }

        _Jump = ground && (_Jump || IsInput());
        _JumpTop = _touchUp && (_Jump || IsInput());
        _WasGround = ground;
    }

    private void FixedUpdate()
    {
        if (Dead)
        {
            Rigidbody2D.velocity = Vector2.zero;
            return;
        }

        Vector2 velocity = Rigidbody2D.velocity;
        velocity.x = Speed * Time.fixedDeltaTime;
        Rigidbody2D.velocity = velocity;

        if (_Jump || _JumpTop )
        {
            Rigidbody2D.AddForce(Vector3.up * _JumpForce * Rigidbody2D.mass, ForceMode2D.Impulse);
            _Jump = false;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == _Obstacle)
        {
            Dead = true;
            GetComponentInChildren<SpriteRenderer>().enabled = false;
            DeadParticles.Play();
            GameManager.Instance.NotifyDead();
        }
        if (collision.CompareTag("portal"))
        {
            Debug.Log("portal");
            Rigidbody2D.gravityScale *= -1;
            _touchUp = true;
        }
    }

    private bool IsInput()
    {
        return Input.GetKey(KeyCode.Space) ||
               Input.GetKey(KeyCode.W) ||
               Input.GetKey(KeyCode.UpArrow) ||
               Input.touchCount > 0;
    }
}
